import { HashRouter, Routes, Route, Navigate } from "react-router-dom";
import ProtectedRoute from "./components/ProtectedRoute";
import Layout from "./components/Layout";
import Dashboard from "./pages/dashboard";
import Companies from "./pages/companies";
import Applications from "./pages/applications";
import AddApplication from "./pages/AddApplication";
import ApplicationDetails from "./pages/ApplicationDetails";
import Login from "./pages/login";
import Landing from "./pages/landing";
import AddCompany from "./pages/AddCompany";
import CompanyDetails from "./pages/CompanyDetails";
import Register from "./pages/Register";
import AdminUsers from "./pages/AdminUsers";
import CareerTools from "./pages/CareerTools";
import Interviews from "./pages/Interviews";
import Notifications from "./pages/Notifications";
import Profile from "./pages/Profile";
import { useAuth } from "./context/AuthContext";

function AdminRoute({ children }) {
    const { user } = useAuth();

    if (user?.email?.toLowerCase() !== "jessiemarkbaronda06@gmail.com") {
        return <Navigate to="/dashboard" replace />;
    }

    return children;
}

function App() {
    return (
        <HashRouter>
            <Routes>

                <Route
                    path="/"
                    element={<Landing />}
                />


                <Route
                    path="/login"
                    element={<Login />}
                />

                <Route path="/register" element={<Register />} />
                <Route
                    path="/admin"
                    element={
                        <ProtectedRoute>
                            <AdminRoute>
                                <Layout>
                                    <AdminUsers />
                                </Layout>
                            </AdminRoute>
                        </ProtectedRoute>
                    }
                />

              <Route
                    path="/dashboard"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <Dashboard />
                                
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/companies"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <Companies />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/applications"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <Applications />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/career-tools"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <CareerTools />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/interviews"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <Interviews />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/notifications"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <Notifications />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/profile"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <Profile />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/applications/create"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <AddApplication />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/applications/edit/:id"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <AddApplication />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/applications/view/:id"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <ApplicationDetails />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/companies/create"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <AddCompany />
                                
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/companies/edit/:id"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <AddCompany />
                            </Layout>
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/companies/view/:id"
                    element={
                        <ProtectedRoute>
                            <Layout>
                                <CompanyDetails />
                            </Layout>
                        </ProtectedRoute>
                    }
                />

            </Routes>
            
        </HashRouter>
    );
}

export default App;