<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        if (strtolower((string) $request->user()?->email) !== 'jessiemarkbaronda06@gmail.com') {
            return response()->json(['message' => 'Administrator access required.'], 403);
        }

        return $next($request);
    }
}