<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\JobApplicationTracker\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>